<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>

<script type='text/javascript'>
	$(function(){
		load_silent('cms/manage/show_menu_grup/','#divsubcontent');
	});
</script>

<div id='divsubcontent'></div>