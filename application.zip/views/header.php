<div class="navigation-bar dark">
    <div class="navigation-bar-content container">
        <a href="/" class="element"><span class="icon-grid-view"></span> METRO UI CSS <sup>2.0</sup></a>
        <span class="element-divider"></span>

        <a class="element1 pull-menu" href="#"></a>
        <ul class="element-menu">
            <li>
                <a class="dropdown-toggle" href="#">Base CSS</a>
                <ul class="dropdown-menu dark" data-role="dropdown">
                    <li><a href="requirements.html">Requirements</a></li>
                    <li>
                        <a href="#" class="dropdown-toggle">General CSS</a>
                        <ul class="dropdown-menu dark" data-role="dropdown">
                            <li><a href="global.html">Global styles</a></li>
                            <li><a href="grid.html">Grid system</a></li>
                            <div class="divider"></div>
                            <li><a href="typography.html">Typography</a></li>
                            <li><a href="tables.html">Tables</a></li>
                            <li><a href="forms.html">Forms</a></li>
                            <li><a href="buttons.html">Buttons</a></li>
                            <li><a href="images.html">Images</a></li>
                        </ul>
                    </li>
                    <li class="divider"></li>
                    <li><a href="responsive.html">Responsive</a></li>
                    <li class="disabled"><a href="layouts.html">Layouts and templates</a></li>
                    <li class="divider"></li>
                    <li><a href="icons.html">Icons</a></li>
                </ul>
            </li>
            <li>
                <a class="dropdown-toggle"  href="#">Components</a>
                <ul class="dropdown-menu dark" data-role="dropdown">
                    <li><a href="tiles.html">Tiles</a></li>
                    <li>
                        <a href="#" class="dropdown-toggle">Navigation</a>
                        <ul class="dropdown-menu dark" data-role="dropdown">
                            <li><a href="navbar.html">Navigation Bar</a></li>
                            <li><a href="menus.html">Menus</a></li>
                            <li><a href="fluent-menu.html">Fluent Menu</a></li>
                            <li><a href="sidebar.html">Sidebar</a></li>
                            <li><a href="tab-control.html">Tab Control</a></li>
                            <li><a href="accordion.html">Accordion</a></li>
                            <li><a href="buttons.html#_set">Button Set</a></li>
                            <li><a href="buttons.html#_breadcrumbs">Breadcrumbs</a></li>
                            <li><a href="wizard.html">Wizard</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" class="dropdown-toggle">Visualisation</a>
                        <ul class="dropdown-menu dark" data-role="dropdown">
                            <li><a href="rating.html">Rating</a></li>
                            <li><a href="progress-bar.html">Progress Bar</a></li>
                            <li><a href="scroll.html">Scroll Bar</a></li>
                            <li><a href="slider.html">Slider</a></li>
                            <li><a href="carousel.html">Carousel</a></li>
                            <li><a href="treeview.html">TreeView</a></li>
                            <li><a href="lists.html">Lists</a></li>
                            <li><a href="hint.html">Hint</a></li>
                            <li><a href="balloon.html">Balloon</a></li>
                            <li><a href="notices.html">Notices</a></li>
                            <li><a href="stepper.html">Stepper</a></li>
                            <li><a href="panels.html">Panel</a></li>
                            <li><a href="streamer.html">Streamer</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" class="dropdown-toggle">Date and Time</a>
                        <ul class="dropdown-menu dark" data-role="dropdown">
                            <li><a href="calendar.html">Calendar</a></li>
                            <li><a href="datepicker.html">DatePicker</a></li>
                            <li><a href="times.html">Times</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" class="dropdown-toggle">Information</a>
                        <ul class="dropdown-menu dark" data-role="dropdown">
                            <li><a href="window.html">Window</a></li>
                            <li><a href="dialog.html">Dialog</a></li>
                            <li><a href="notify.html">Notify</a></li>
                        </ul>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a href="#" class="dropdown-toggle">Third-party</a>
                        <ul class="dropdown-menu dark" data-role="dropdown">
                            <li><a href="dataTables.html">DataTables</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#" class="dropdown-toggle">Templates</a>
                <ul class="dropdown-menu dark" data-role="dropdown">
                    <li><a href="template-news-portal.html">News Portal (msn.com)</a></li>
                </ul>
            </li>
            <li>
                <a class="dropdown-toggle"  href="#">Community</a>
                <ul class="dropdown-menu dark" data-role="dropdown">
                    <li class="disabled"><a href="http://blog.metroui.net">Blog</a></li>
                    <li class="disabled"><a href="http://forum.metroui.net">Community Forum</a></li>
                    <li class="divider"></li>
                    <li><a href="https://github.com/olton/Metro-UI-CSS">Github</a></li>
                    <li class="divider"></li>
                    <li><a href="https://github.com/olton/Metro-UI-CSS/blob/master/LICENSE">License</a></li>
                </ul>
            </li>
            <li>
                <a href="#" class="dropdown-toggle fg-yellow">Examples</a>
                <ul class="dropdown-menu dark" data-role="dropdown">
                    <li><a href="examples.html">Top page</a></li>
                    <li class="divider"></li>

                    <li>
                        <a href="#" class="dropdown-toggle">General</a>
                        <ul class="dropdown-menu dark" data-role="dropdown">
                            <li><a href="examples.html#__table__">Table</a></li>
                            <li><a href="examples.html#__form__">Form</a></li>
                            <li><a href="examples.html#__buttons__">Buttons</a></li>
                            <li><a href="examples.html#__image__">Images</a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="#" class="dropdown-toggle">Navigation</a>
                        <ul class="dropdown-menu dark" data-role="dropdown">
                            <li><a href="examples.html#__navbar__">Navigation bar</a></li>
                            <li><a href="examples.html#__dropdown__">Dropdown menu</a></li>
                            <li><a href="examples.html#__sidebar__">Sidebar</a></li>
                            <li><a href="examples.html#__tabs__">Tab control</a></li>
                            <li><a href="examples.html#__accordion__">Accordion</a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="#" class="dropdown-toggle">Visualization</a>
                        <ul class="dropdown-menu dark" data-role="dropdown">
                            <li><a href="examples.html#__tile__">Tiles</a></li>
                            <li><a href="examples.html#__rating__">Rating</a></li>
                            <li><a href="examples.html#__progress__">Progress bar</a></li>
                            <li><a href="examples.html#__scroll__">Scroll bar</a></li>
                            <li><a href="examples.html#__slider__">Slider</a></li>
                            <li><a href="examples.html#__carousel__">Carousel</a></li>
                            <li><a href="examples.html#__tree__">Tree view</a></li>
                            <li><a href="examples.html#__lists__">List view</a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="#" class="dropdown-toggle">Visualization 2</a>
                        <ul class="dropdown-menu dark" data-role="dropdown">
                            <li><a href="examples.html#__hint__">Hint</a></li>
                            <li><a href="examples.html#__balloon__">Balloon</a></li>
                            <li><a href="examples.html#__notice__">Notice</a></li>
                            <li><a href="examples.html#__calendar__">Calendar</a></li>
                            <li><a href="examples.html#__times__">Countdown &amp; Times</a></li>
                            <li><a href="examples.html#__window__">Windows</a></li>
                            <li><a href="examples.html#__streamer__">Streamer</a></li>
                            <li><a href="examples.html#__panel__">Panel</a></li>
                            <li><a href="examples.html#__stepper__">Stepper</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>

        <div class="no-tablet-portrait no-phone">
            <a title="Nuget.org" href="https://www.nuget.org/packages/Metro.UI.CSS/" class="element place-right"><span class="icon-box-add"></span></a>
            <span class="element-divider place-right"></span>
            <a title="GitHub" href="https://github.com/olton/Metro-UI-CSS" class="element place-right"><span class="icon-github"></span></a>
            <span class="element-divider place-right"></span>
            <a title="CSS3 validator" href="http://jigsaw.w3.org/css-validator/validator?uri=metroui.org.ua&profile=css3&usermedium=all&warning=no&vextwarning=" class="element place-right"><span class="icon-css3"></span></a>
            <span class="element-divider place-right"></span>
            <div class="element place-right" title="GitHub Stars"><span class="icon-star"></span> <span class="github-watchers">0</span></div>
            <!--<span class="element-divider place-right"></span>-->
            <!--<div class="element place-right" title="GitHub Forks"><span class="icon-share-2"></span> <span class="github-forks">0</span></div>-->
        </div>
    </div>
</div>
