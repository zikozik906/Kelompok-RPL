
        <div class="box-body">
        <div class="row">
        <div class="col-sm-12 border-right">
        <?php require_once ('application/views/dasbord.php') ?>
        <?php require_once ('application/views/dasbord.php') ?>
        </div>
        </div>
        </div>
        